function init() {
    //
    $('.sidebar-menu').tree();
    //
    $("#msg-alert").fadeTo(2000, 500).slideUp(500, function () {
        $("#msg-alert").slideUp(1000);
    });
    //
    $('.openBtn').on('click', function () {
        $('#loader').show();
        var dataURL = $(this).attr('data-href');
        $('.modal-body').load(dataURL, function () {
            $('#mod-title').html('Employee Profile');
            $('#openModal').modal({
                show: true
            });
            $('#loader').hide();
        });
    });
}